package com.example.EteBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EteBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
